import setuptools

setuptools.setup(
    name="multi_person_tracker",
    version="0.1",
    author="Muhammed Kocabas",
    description="Multi Person Tracker",
    packages=setuptools.find_packages(),
    python_requires='>=3.6',
)